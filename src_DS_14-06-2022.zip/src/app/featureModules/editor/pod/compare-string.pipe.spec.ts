import { CompareStringPipe } from './compare-string.pipe';

describe('CompareStringPipe', () => {
  it('create an instance', () => {
    const pipe = new CompareStringPipe();
    expect(pipe).toBeTruthy();
  });
});
